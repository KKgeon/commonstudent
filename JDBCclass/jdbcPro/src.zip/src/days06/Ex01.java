package days06;

import java.sql.Connection;

import com.util.DBConn;

public class Ex01 {
	public static void main(String[] args) {
		Connection conn = DBConn.getConnection(); //DB연결하는 작업.
		
		
		
		
	}
}
