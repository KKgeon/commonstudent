package days05;

public class Ex00 {

	
	
	
}
