package days01;

public class Ex01 {
	public static void main(String[] args) {
		System.out.println("강명건");
		System.out.println("Hello World~");
	}
}
