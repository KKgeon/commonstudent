package days03;

public class Ex02 {
	public static void main(String[] args) {
		// ㄴ presistence 패키지 추가
		// 		ㄴ Data Access Object [DAO]
		//		DB 처리하는 기능(메서드) 구현된 클래스
		//		EmpDAO 인터페이스 추가
		//		EmpDAOImpl.java 클래스 추가
		
		
		// ㄴ EmpVO
		//		private java.util.Date hiredate;
	}//m
}//c
