package days04;

public class Ex01 {
	public static void main(String[] args) {

	}//m
}//c
